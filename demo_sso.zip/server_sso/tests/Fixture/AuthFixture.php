<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AuthFixture
 */
class AuthFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'auth';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'email' => 'Lorem ipsum dolor sit amet',
                'password' => 'Lorem ipsum dolor sit amet',
                'create_on' => 1701935597,
                'update_on' => 1701935597,
            ],
        ];
        parent::init();
    }
}
