<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\AuthTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\AuthTable Test Case
 */
class AuthTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\AuthTable
     */
    protected $Auth;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Auth',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Auth') ? [] : ['className' => AuthTable::class];
        $this->Auth = $this->getTableLocator()->get('Auth', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Auth);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\AuthTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
