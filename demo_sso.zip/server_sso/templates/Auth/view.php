<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Auth $auth
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Auth'), ['action' => 'edit', $auth->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Auth'), ['action' => 'delete', $auth->id], ['confirm' => __('Are you sure you want to delete # {0}?', $auth->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Auth'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Auth'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="auth view content">
            <h3><?= h($auth->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($auth->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= h($auth->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($auth->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Create On') ?></th>
                    <td><?= h($auth->create_on) ?></td>
                </tr>
                <tr>
                    <th><?= __('Update On') ?></th>
                    <td><?= h($auth->update_on) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
